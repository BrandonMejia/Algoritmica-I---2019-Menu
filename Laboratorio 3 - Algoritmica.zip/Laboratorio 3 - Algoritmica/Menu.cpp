#include <iostream>
#include <stdio.h>
#include <stdlib.h>


using namespace std;

void menu(){
    cout<<"\n\tPrograma para calcular los sueldos\n";
    cout<<"1. Ingreso de Datos"<<endl;
    cout<<"2. Porcentajes"<<endl;
    cout<<"3.system("cls"); Pago Total"<<endl;
    cout<<"0. Salir"<<endl;
    }

int main(){
    char opc = ' ';
    char Nombre[20];
    float sueldo, st=0,ct=0;
    int c=0,cn=0,n;
    do{
    system("cls");
    menu();
    cin>>opc;system("cls");
    switch(opc){
        case '1':

            cout<<"Ingrese numero de trabajadores"<<endl;
            cin>>n;
            for(int i=1; i<=n; i++){
                cout<<"Ingrese nombre de trabajador: ";
                fflush(stdin);
                cin.getline(Nombre,20,'\n');
                do{
                    cout<<"Ingrese sueldo de trabajador: ";
                    fflush(stdin);
                    cin>>sueldo;
                if(sueldo>2000 || sueldo<1000){
                cout<<"DATO ERRONEO"<<endl;
                    }
                }while(sueldo>2000 || sueldo<1000);
                if(sueldo>=1000 && sueldo<1500){
                c=c+1;
                    }
                if(sueldo>=1500 && sueldo<=2000){
                cn=cn+1;
                    }
            ct=ct+1;
            st=st+sueldo;
            }//for
            break;
        case '2':
            if(ct != 0){
            cout<<"PORCENTAJE SUELDO 1000 Y 1500: "<<c/ct*100<<"%"<<endl;
            cout<<"PORCENTAJE SUELDO 1500 Y 2000: "<<cn/ct*100<<"%"<<endl;
            }
            else{
                cout<<"Ingrese datos validos"<<endl;
            }
            break;
        case '3':
            cout<<"SUELDO A PAGAR POR LA EMPRESA "<<st<<endl;
            break;
        case '0':
            break;
        default:
            cout<<"Dato no valido"<<endl;
        }//switch
        system("pause");
    }while(opc != '0');

    return 0;


    }
